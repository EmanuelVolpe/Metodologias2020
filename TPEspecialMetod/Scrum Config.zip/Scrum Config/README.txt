Pegar los archivos en las siguientes ubicaciones

-env.properties en el directorio raíz del proyecto, a la misma altura del archivo gradlew
-google-services.json en la carpeta /app (En caso de querer usar la cuenta de Firebase configurada para producción en vez de la desarrollo, renombrar google-servicesPROD.json por google-services.json)